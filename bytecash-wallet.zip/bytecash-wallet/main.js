
const { app, BrowserWindow, ipcMain, Menu, dialog } = require('electron');
const path = require('path');
const BillVerifier = require('./crypto');

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1400,
    height: 900,
    minWidth: 1200,
    minHeight: 700,
    backgroundColor: '#0f0c29',
    titleBarStyle: 'hiddenInset',
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true
    },
    icon: path.join(__dirname, 'assets', 'icon.png'),
  });

  // Create application menu
  const template = [
    {
      label: 'File',
      submenu: [
        {
          label: 'Import Bill',
          accelerator: 'CmdOrCtrl+I',
          click: () => { mainWindow.webContents.send('import-bill'); }
        },
        {
          label: 'Export Wallet',
          accelerator: 'CmdOrCtrl+E',
          click: () => { mainWindow.webContents.send('export-wallet'); }
        },
        { type: 'separator' },
        { role: 'quit' }
      ]
    },
    {
      label: 'Wallet',
      submenu: [
        {
          label: 'Send Payment',
          accelerator: 'CmdOrCtrl+S',
          click: () => { mainWindow.webContents.send('send-payment'); }
        },
        {
          label: 'Receive Payment',
          accelerator: 'CmdOrCtrl+R',
          click: () => { mainWindow.webContents.send('receive-payment'); }
        },
        {
          label: 'Scan QR Code',
          accelerator: 'CmdOrCtrl+Q',
          click: () => { mainWindow.webContents.send('scan-qr'); }
        }
      ]
    },
    {
      label: 'View',
      submenu: [
        { role: 'reload' },
        { role: 'forceReload' },
        { role: 'toggleDevTools' },
        { type: 'separator' },
        { role: 'resetZoom' },
        { role: 'zoomIn' },
        { role: 'zoomOut' },
        { type: 'separator' },
        { role: 'togglefullscreen' }
      ]
    },
    {
      label: 'Help',
      submenu: [
        {
          label: 'Documentation',
          click: async () => {
            const { shell } = require('electron');
            await shell.openExternal('https://cryptocash.ct.ws');
          }
        },
        {
          label: 'About Bytecash Electrum',
          click: () => {
            dialog.showMessageBox(mainWindow, {
              type: 'info',
              title: 'About Bytecash Electrum',
              message: 'Bytecash Electrum Wallet',
              detail: 'Version 1.0.0\n\nSecure offline cryptocurrency wallet\nwith cryptographic verification.\n\n© 2024 Bytecash'
            });
          }
        }
      ]
    }
  ];

  const menu = Menu.buildFromTemplate(template);
  Menu.setApplicationMenu(menu);

  mainWindow.loadFile('index.html');

  // Open DevTools in development
  if (process.env.NODE_ENV === 'development') {
    mainWindow.webContents.openDevTools();
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  createWindow();

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});

// Bill verification handlers
const verifier = new BillVerifier();

ipcMain.handle('verify-bill', async (event, billData) => {
  return await verifier.verifyBill(billData);
});

ipcMain.handle('accept-bill', async (event, billData) => {
  return await verifier.acceptBill(billData);
});

ipcMain.handle('get-spent-count', async () => {
  return verifier.getSpentList().length;
});

ipcMain.handle('import-bill-file', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [
      { name: 'Bytecash Bills', extensions: ['enc'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });

  if (!result.canceled && result.filePaths.length > 0) {
    return result.filePaths[0];
  }
  return null;
});

ipcMain.handle('export-wallet', async () => {
  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: 'bytecash-wallet-backup.json',
    filters: [
      { name: 'JSON Files', extensions: ['json'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });

  if (!result.canceled) {
    return result.filePath;
  }
  return null;
});

// New handlers for complete wallet functionality

ipcMain.handle('get-all-bills', async () => {
  return verifier.getAllBills();
});

ipcMain.handle('get-total-balance', async () => {
  return verifier.getTotalBalance();
});

ipcMain.handle('import-bill', async (event, filePath) => {
  try {
    const fs = require('fs');
    const billData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    
    const result = await verifier.acceptBill(billData);
    return result;
  } catch (error) {
    return {
      success: false,
      verification: {
        valid: false,
        reason: `Error reading bill file: ${error.message}`
      }
    };
  }
});

ipcMain.handle('export-wallet-data', async (event, filePath) => {
  try {
    const fs = require('fs');
    const walletData = verifier.exportWallet();
    fs.writeFileSync(filePath, JSON.stringify(walletData, null, 2));
    return { success: true, data: walletData };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('import-wallet-data', async (event, filePath) => {
  try {
    const fs = require('fs');
    const walletData = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    const result = verifier.importWallet(walletData);
    return { success: true, result };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

ipcMain.handle('get-security-checklist', async (event, billData) => {
  return verifier.getSecurityChecklist(billData);
});

ipcMain.handle('delete-bill', async (event, serialNumber) => {
  try {
    verifier.deleteBill(serialNumber);
    return { success: true };
  } catch (error) {
    return { success: false, error: error.message };
  }
});

// Send bill handlers (export and delete)
ipcMain.handle('export-bill-file', async (event, serialNumber) => {
  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: `${serialNumber}.enc`,
    filters: [
      { name: 'Bytecash Bills', extensions: ['enc'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });

  if (!result.canceled) {
    return result.filePath;
  }
  return null;
});

ipcMain.handle('send-bill', async (event, billData, filePath) => {
  try {
    const fs = require('fs');
    
    // 1. Export the bill to file for transfer
    fs.writeFileSync(filePath, JSON.stringify(billData, null, 2));
    
    // 2. Mark the bill as spent (prevents double-spending)
    verifier.markAsSpent(billData.serialNumber);
    
    // 3. CRITICAL SECURITY: DELETE the bill from sender's wallet
    // This ensures the sender cannot re-use or re-send the bill
    verifier.deleteBill(billData.serialNumber);
    
    return { 
      success: true,
      message: 'Bill exported and deleted from wallet - no copies retained'
    };
  } catch (error) {
    return { success: false, error: error.message };
  }
});
