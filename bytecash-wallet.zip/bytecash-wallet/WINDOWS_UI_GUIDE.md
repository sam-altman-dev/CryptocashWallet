
# Windows UI Screenshots Guide - Bytecash Electrum

This document describes what each UI element looks like on Windows.

## 1. Application Launch

**What you see:**
- Windows start menu entry: "Bytecash Electrum"
- Desktop shortcut with Electron icon (or custom icon if provided)
- Initial splash screen (Electron default) before main window appears

**Source Code Reference:**
- `main.js` lines 5-20: Window creation
- `package.json` build.win configuration

---

## 2. Main Window (First Launch)

**Visual Description:**
```
┌─────────────────────────────────────────────────────────────────┐
│ Bytecash Electrum                                    [_][□][X] │ ← Windows title bar
├───────────┬─────────────────────────────────────────────────────┤
│           │ Portfolio                    📷 Scan    + Import    │ ← Header
│ BYTECASH  │                                                      │
│ ELECTRUM  │ ┌───────────────────────────────────────────────┐  │
│           │ │ TOTAL BALANCE                                  │  │
│ 💰 Wallet │ │ $170.00                                        │  │ ← Balance Card
│ 📊 Trans  │ │ 3 Bills • Last sync: Just now                  │  │
│ 📤 Send   │ │ [Send Payment] [Request] [Export Wallet]       │  │
│ 📥 Receive│ └───────────────────────────────────────────────┘  │
│ 🔍 Verify │                                                      │
│ ⚙️ Settings│ Your Bills                          3 bills verified│
│           │                                                      │
│           │ ┌──────┐ ┌──────┐ ┌──────┐                         │
│ ● Offline │ │ $20  │ │ $50  │ │ $100 │                         │ ← Bill Cards Grid
│   Secure  │ │ ✓    │ │ ✓    │ │ ✓    │                         │
│           │ └──────┘ └──────┘ └──────┘                         │
└───────────┴─────────────────────────────────────────────────────┘
```

**Source Code:**
- `index.html` line 46-end: Complete HTML structure
- `main.js` lines 6-13: Window dimensions and styling

---

## 3. Sidebar Navigation

**Active State (Wallet selected):**
```
│ 💰 Wallet │ ← Green background glow + left green border
│ 📊 Trans  │
```

**Hover State:**
```
│ 💰 Wallet │
│ 📊 Trans  │ ← Lighter background on hover
```

**Source Code:**
- `index.html` styles lines 72-93: .nav-item CSS
- Lines 87-92: .nav-item.active styling

---

## 4. Balance Card Details

**Visible Elements:**
```
┌─────────────────────────────────────┐
│ TOTAL BALANCE                       │ ← Gray uppercase label
│ $170.00                             │ ← Huge green glowing number
│ 3 Bills • Last sync: Just now       │ ← Gray metadata
│                                     │
│ [Send Payment] [Request] [Export]   │ ← Action buttons
└─────────────────────────────────────┘
```

**Green glow effect visible around $170.00**

**Source Code:**
- `index.html` lines 271-285: Balance card HTML
- Lines 173-196: .balance-card CSS styling
- Line 183: text-shadow for glow effect

---

## 5. Bill Card - $20 (Green)

**Visual Layout:**
```
┌─ ← 4px green vertical bar
│ $20                        ✓ Verified │ ← Header
│ BC-X9K2L-7823-MNOP                    │ ← Serial
│ Signature: MEUCIQDa7B...x9F           │ ← Truncated signature
├────────────────────────────────────────│
│ Position: 1           Offline Secure  │ ← Footer
└────────────────────────────────────────┘
```

**Colors:**
- Left accent bar: #10B981 (emerald green)
- Denomination: #10B981
- Background: Very dark with subtle transparency

**Hover Effect:**
- Card lifts up 2px
- Shadow intensifies
- Border brightens

**Source Code:**
- `index.html` lines 227-265: Bill card CSS
- Lines 342-367: Bill data and rendering JavaScript
- Line 251: --bill-color CSS variable usage

---

## 6. Bill Card - $50 (Blue)

**Same layout as $20 but:**
- Left accent bar: #3B82F6 (blue)
- Denomination color: #3B82F6

**Source Code:**
- Same as $20, color from bill.color property

---

## 7. Bill Card - $100 (Purple)

**Same layout but:**
- Left accent bar: #8B5CF6 (purple)
- Denomination color: #8B5CF6

---

## 8. Matrix Background Effect

**What you see:**
- Very faint green characters falling slowly
- Characters: "0", "1", and Japanese katakana
- Barely visible (3% opacity)
- Continuous animation

**Source Code:**
- `index.html` lines 296-329: Matrix canvas JavaScript
- Line 142: .matrix-bg CSS with opacity: 0.03

---

## 9. Windows Menu Bar

**File Menu Click:**
```
File ▼
  Import Bill           Ctrl+I
  Export Wallet         Ctrl+E
  ──────────────────────────
  Quit
```

**Source Code:**
- `main.js` lines 23-73: Menu template definition
- Lines 25-38: File menu items

---

## 10. Wallet Menu

**When clicked:**
```
Wallet ▼
  Send Payment          Ctrl+S
  Receive Payment       Ctrl+R
  Scan QR Code          Ctrl+Q
```

**Source Code:**
- `main.js` lines 40-55: Wallet menu configuration

---

## 11. Help > About Dialog

**Windows modal dialog:**
```
┌─────────────────────────────────────┐
│ About Bytecash Electrum        [X] │
│                                     │
│ (i) Bytecash Electrum Wallet        │
│                                     │
│     Version 1.0.0                   │
│                                     │
│     Secure offline cryptocurrency   │
│     wallet with cryptographic       │
│     verification.                   │
│                                     │
│     © 2024 Bytecash                 │
│                                     │
│              [ OK ]                 │
└─────────────────────────────────────┘
```

**Source Code:**
- `main.js` lines 66-76: About dialog configuration

---

## 12. Import Bill File Picker (Windows Native)

**Standard Windows file dialog:**
```
Open Bill File
┌─────────────────────────────────────────┐
│ Look in: [Documents          ▼]  [X]  │
├─────────────────────────────────────────┤
│ 📁 Desktop                              │
│ 📁 Downloads                            │
│ 📁 Documents                            │
│   📄 bill_001.enc                       │
│   📄 bill_002.enc                       │
├─────────────────────────────────────────┤
│ File name: [________________]           │
│ Files of type: [Bytecash Bills (*.enc)▼]│
│                    [Open]  [Cancel]     │
└─────────────────────────────────────────┘
```

**Source Code:**
- `main.js` lines 122-132: Import file dialog

---

## 13. Export Wallet Save Dialog (Windows)

**Standard Windows save dialog:**
```
Save Wallet Backup
┌─────────────────────────────────────────┐
│ Save in: [Documents          ▼]  [X]  │
├─────────────────────────────────────────┤
│ 📁 Desktop                              │
│ 📁 Downloads                            │
│ 📁 Documents                            │
├─────────────────────────────────────────┤
│ File name: [bytecash-wallet-backup.json]│
│ Save as type: [JSON Files (*.json)   ▼] │
│                    [Save]  [Cancel]     │
└─────────────────────────────────────────┘
```

**Source Code:**
- `main.js` lines 134-146: Export save dialog

---

## 14. Button Interaction States

### Primary Button (Send Payment)

**Normal:**
```
┌──────────────┐
│ Send Payment │ ← Solid green (#00ff00) background
└──────────────┘
```

**Hover:**
```
┌──────────────┐
│ Send Payment │ ← Brighter green + glow shadow
└──────────────┘   ⌇ shadow visible below
```

**Source Code:**
- `index.html` lines 120-135: Button CSS
- Lines 127-130: .btn-primary hover state

### Secondary Button (Scan Bill)

**Normal:**
```
┌──────────────┐
│ 📷 Scan Bill │ ← Outlined, transparent background
└──────────────┘
```

**Hover:**
```
┌──────────────┐
│ 📷 Scan Bill │ ← Background fills slightly
└──────────────┘
```

---

## 15. Scrollbar (When content overflows)

**Visual appearance:**
```
│              ║ ← Very thin (8px) scrollbar
│              ║   Track: Dark transparent
│              █   Thumb: Green semi-transparent
│              ║   Rounds on hover
│              ║
```

**Source Code:**
- `index.html` lines 267-279: Scrollbar CSS

---

## 16. Status Indicator Animation

**Bottom of sidebar:**
```
┌──────────────────┐
│ ● Offline Secure │ ← Green dot pulses (fades in/out)
└──────────────────┘
```

**Animation:** 2-second pulse cycle

**Source Code:**
- `index.html` lines 281-287: Status indicator CSS
- Lines 289-293: @keyframes pulse animation

---

## 17. Installation Wizard (Windows)

**NSIS Installer screens:**

**Screen 1 - Welcome:**
```
Welcome to Bytecash Electrum Setup
This will install Bytecash Electrum on your computer.
[Next >]  [Cancel]
```

**Screen 2 - Choose Install Location:**
```
Choose Install Location
Destination Folder: C:\Program Files\Bytecash Electrum
[Browse...]
[< Back]  [Next >]  [Cancel]
```

**Screen 3 - Choose Components:**
```
☑ Desktop shortcut
☑ Start Menu shortcut
[< Back]  [Install]  [Cancel]
```

**Screen 4 - Installing:**
```
Installing...
[████████░░░░░░░░] 60%
```

**Screen 5 - Completion:**
```
Setup Complete
☑ Launch Bytecash Electrum
[Finish]
```

**Source Code:**
- `package.json` lines 16-34: electron-builder NSIS config

---

## Complete Source File Locations

1. **Main Window:** `desktop-wallet/index.html`
2. **Window Configuration:** `desktop-wallet/main.js` lines 5-20
3. **Menu Bar:** `desktop-wallet/main.js` lines 23-76
4. **IPC Handlers:** `desktop-wallet/main.js` lines 114-146
5. **Styles:** `desktop-wallet/index.html` lines 10-294 (embedded CSS)
6. **JavaScript:** `desktop-wallet/index.html` lines 296-405 (embedded JS)
7. **Build Config:** `desktop-wallet/package.json` lines 8-36

---

## Windows-Specific Features

1. **Title Bar:** Standard Windows chrome with minimize/maximize/close
2. **Task Bar:** Shows in Windows taskbar with icon
3. **System Tray:** Could be added for background operation
4. **File Associations:** .enc files could auto-open in wallet
5. **Notifications:** Windows 10/11 notification system compatible
6. **Installer:** NSIS with all standard Windows conventions

---

All UI elements follow Windows design conventions while maintaining the Matrix/Coinbase aesthetic.
