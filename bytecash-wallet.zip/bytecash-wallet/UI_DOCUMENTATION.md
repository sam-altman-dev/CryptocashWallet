
# Bytecash Electrum Desktop Wallet - UI Documentation

## Application Overview

The Bytecash Electrum wallet is a secure, offline cryptocurrency wallet with a Matrix-inspired design theme inspired by Coinbase's professional aesthetic.

---

## Main Application Window

**Window Specifications:**
- Default Size: 1400x900 pixels
- Minimum Size: 1200x700 pixels
- Background: Dark gradient (#0f0c29 → #302b63 → #24243e)
- Title Bar: Hidden/Inset style for modern look

**Screenshot Description:** 
Full application window with sidebar on left, main content area on right, showing the Matrix rain animation in the background at 3% opacity.

---

## Left Sidebar Navigation

**Visual Design:**
- Width: 240px
- Background: rgba(15, 12, 41, 0.95)
- Border: 1px solid rgba(0, 255, 0, 0.1) on right edge

### Logo Section
- **Text:** "BYTECASH" in bright green (#00ff00)
- **Font:** 24px, bold, with glow effect
- **Subtitle:** "Electrum" in gray, 11px, uppercase
- **Screenshot:** Top of sidebar showing logo and branding

### Navigation Menu Items
Each menu item shows:
- Icon emoji (💰, 📊, 📤, 📥, 🔍, ⚙️)
- Label text
- Hover state: rgba(0, 255, 0, 0.1) background
- Active state: rgba(0, 255, 0, 0.15) background with 3px green left border

**Menu Items:**
1. **Wallet** (Active by default) - 💰 icon
2. **Transactions** - 📊 icon
3. **Send** - 📤 icon
4. **Receive** - 📥 icon
5. **Verify** - 🔍 icon
6. **Settings** - ⚙️ icon

**Screenshot:** Sidebar navigation with "Wallet" item highlighted in active state

### Status Indicator (Bottom)
- Green pulsing dot animation
- Text: "Offline Secure"
- Background: rgba(0, 255, 0, 0.1)
- Rounded pill shape

**Screenshot:** Status indicator at bottom of sidebar

---

## Top Header Bar

**Visual Design:**
- Background: rgba(15, 12, 41, 0.8)
- Border bottom: 1px solid rgba(0, 255, 0, 0.1)
- Padding: 20px 30px

### Left Side
- **Title:** "Portfolio" - 28px, font-weight 600

### Right Side Action Buttons
1. **Scan Bill Button**
   - Text: "📷 Scan Bill"
   - Style: Secondary (outlined green)
   - Background: rgba(0, 255, 0, 0.1)
   - Border: 1px solid rgba(0, 255, 0, 0.3)

2. **Import Bill Button**
   - Text: "+ Import Bill"
   - Style: Primary (solid green)
   - Background: #00ff00
   - Color: #0f0c29 (dark text on green)
   - Hover: Adds glow shadow

**Screenshot:** Header bar showing title and action buttons

---

## Main Content Area - Balance Card

**Visual Design:**
- Background: Linear gradient rgba(0, 255, 0, 0.1) → rgba(0, 150, 0, 0.05)
- Border: 1px solid rgba(0, 255, 0, 0.2)
- Border radius: 16px
- Padding: 32px
- Backdrop filter: blur(10px)

### Content Structure:

1. **Balance Label**
   - Text: "TOTAL BALANCE" (uppercase)
   - Color: #888
   - Font size: 14px
   - Letter spacing: 1px

2. **Balance Amount**
   - Text: "$170.00" (example)
   - Color: #00ff00 (bright green)
   - Font size: 48px, bold
   - Text shadow: 0 0 30px rgba(0, 255, 0, 0.3)

3. **Metadata**
   - Text: "3 Bills • Last sync: Just now"
   - Color: #aaa
   - Font size: 18px

4. **Quick Action Buttons** (3 buttons in a row)
   - **Send Payment** - Primary green button (flex: 1)
   - **Request Payment** - Secondary outlined button (flex: 1)
   - **Export Wallet** - Secondary outlined button

**Screenshot:** Complete balance card showing all elements with green glow effects

---

## Bills Section

**Header:**
- Title: "Your Bills" - 20px, font-weight 600
- Metadata: "3 bills verified" - gray, 14px

### Bills Grid Layout
- Display: CSS Grid
- Columns: Auto-fill, minimum 320px
- Gap: 20px between cards

### Individual Bill Card

**Visual Design:**
- Background: rgba(255, 255, 255, 0.03)
- Border: 1px solid rgba(0, 255, 0, 0.15)
- Border radius: 12px
- Padding: 20px
- Left accent: 4px colored bar (color varies by denomination)
- Hover: Elevates with shadow and color intensifies

**Card Structure:**

1. **Header Row** (flex, space-between)
   - **Denomination:** "$20", "$50", or "$100" in large bold text
     - Colors: $20=#10B981 (green), $50=#3B82F6 (blue), $100=#8B5CF6 (purple)
     - Font size: 32px, bold
   - **Status Badge:** "✓ Verified"
     - Background: rgba(0, 255, 0, 0.2)
     - Color: #00ff00
     - Padding: 4px 12px
     - Border radius: 12px
     - Font: 11px, uppercase, bold

2. **Serial Number**
   - Font: Courier New (monospace)
   - Example: "BC-X9K2L-7823-MNOP"
   - Color: #aaa
   - Font size: 13px

3. **Signature Preview**
   - Font: Courier New (monospace)
   - Example: "Signature: MEUCIQDa7B...x9F"
   - Color: #666
   - Font size: 11px
   - Truncated with ellipsis

4. **Footer** (border-top separator)
   - Left: "Position: 1"
   - Right: "Offline Secure"
   - Color: #888
   - Font size: 12px

**Screenshot Examples:**
- Screenshot 1: $20 bill card with green accent
- Screenshot 2: $50 bill card with blue accent
- Screenshot 3: $100 bill card with purple accent
- Screenshot 4: Bill card hover state showing elevated shadow

---

## Matrix Background Animation

**Technical Details:**
- Canvas element covering entire window
- Opacity: 0.03 (very subtle)
- Characters: "01" + Japanese katakana characters
- Font: 14px monospace
- Color: #00ff00
- Animation: Falling characters at 50ms intervals
- Z-index: 0 (behind all content)

**Screenshot:** Full window showing subtle Matrix rain effect

---

## Application Menu Bar

### File Menu
1. **Import Bill** - Keyboard: Cmd/Ctrl+I
2. **Export Wallet** - Keyboard: Cmd/Ctrl+E
3. **Separator**
4. **Quit** - Standard quit option

### Wallet Menu
1. **Send Payment** - Keyboard: Cmd/Ctrl+S
2. **Receive Payment** - Keyboard: Cmd/Ctrl+R
3. **Scan QR Code** - Keyboard: Cmd/Ctrl+Q

### View Menu
1. **Reload**
2. **Force Reload**
3. **Toggle DevTools**
4. **Separator**
5. **Reset Zoom**
6. **Zoom In**
7. **Zoom Out**
8. **Separator**
9. **Toggle Fullscreen**

### Help Menu
1. **Documentation** - Opens https://cryptocash.ct.ws
2. **About Bytecash Electrum** - Shows version dialog

**Screenshot:** Menu bar open showing all menu options

---

## Dialog Windows

### About Dialog
- Type: Info
- Title: "About Bytecash Electrum"
- Message: "Bytecash Electrum Wallet"
- Detail: "Version 1.0.0\n\nSecure offline cryptocurrency wallet\nwith cryptographic verification.\n\n© 2024 Bytecash"

**Screenshot:** About dialog box

### Import Bill File Picker
- Filter: .enc files (Bytecash Bills)
- Title: "Open Bill File"
- Native system file dialog

**Screenshot:** File picker dialog (Windows native)

### Export Wallet File Picker
- Default name: "bytecash-wallet-backup.json"
- Filter: .json files
- Title: "Save Wallet Backup"

**Screenshot:** Save dialog (Windows native)

---

## Color Palette Reference

**Primary Colors:**
- Matrix Green: #00ff00
- Dark Purple Base: #0f0c29
- Mid Purple: #302b63
- Dark Slate: #24243e

**Bill Denomination Colors:**
- $20: #10B981 (emerald green)
- $50: #3B82F6 (blue)
- $100: #8B5CF6 (purple)

**UI Element Colors:**
- Text Primary: #ffffff
- Text Secondary: #aaa
- Text Tertiary: #888
- Monospace Text: #666
- Borders: rgba(0, 255, 0, 0.1-0.3)
- Card Backgrounds: rgba(255, 255, 255, 0.03-0.05)

---

## Interaction States

### Button States:
1. **Normal:** Defined background and border
2. **Hover:** Brighter background, glow shadow appears
3. **Active/Pressed:** Slightly darker, reduced shadow
4. **Disabled:** Opacity 0.5, no hover effects

### Navigation States:
1. **Default:** Transparent background
2. **Hover:** rgba(0, 255, 0, 0.1)
3. **Active:** rgba(0, 255, 0, 0.15) + left border

### Bill Card States:
1. **Normal:** Base appearance
2. **Hover:** translateY(-2px), enhanced shadow, brighter border
3. **Click:** Opens detailed view (alert in current implementation)

---

## Scrollbar Styling

- Width: 8px
- Track: rgba(0, 0, 0, 0.2)
- Thumb: rgba(0, 255, 0, 0.3)
- Thumb Hover: rgba(0, 255, 0, 0.5)
- Border radius: 4px

**Screenshot:** Scrollbar detail when content overflows

---

## Build Output Locations

**Windows:**
- Path: `desktop-wallet/dist/Bytecash Electrum Setup 1.0.0.exe`
- Type: NSIS installer
- Architectures: x64, ia32 (32-bit)
- Features: Desktop shortcut, start menu entry, uninstaller

**macOS:**
- Path: `desktop-wallet/dist/Bytecash Electrum-1.0.0.dmg`
- Additional: `desktop-wallet/dist/Bytecash Electrum-1.0.0-mac.zip`
- Type: DMG disk image + ZIP archive
- Architecture: Universal (Intel + Apple Silicon recommended)

**Linux:**
- Path: `desktop-wallet/dist/Bytecash Electrum-1.0.0.AppImage`
- Additional: `desktop-wallet/dist/bytecash-electrum_1.0.0_amd64.deb`
- Types: AppImage (universal) and Debian package

---

## Development vs Production

**Development Mode:**
- DevTools open by default
- Hot reload enabled
- Debug logging enabled

**Production Mode:**
- DevTools hidden
- Optimized bundle
- No debug output
- Code signed (when configured)

---

This documentation describes all UI interactions visible in the Bytecash Electrum desktop wallet application.
