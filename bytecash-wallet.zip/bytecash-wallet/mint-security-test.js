
const BillVerifier = require('./crypto');
const crypto = require('crypto');
const fs = require('fs');

console.log('\n🔐 MINT SECURITY & REVERSE ENGINEERING PROTECTION TEST');
console.log('═════════════════════════════════════════════════════════\n');

const verifier = new BillVerifier();
let testsPassed = 0;
let testsFailed = 0;

function test(name, fn) {
  try {
    const result = fn();
    if (result === true || (result && result.then)) {
      return result.then ? result.then(() => {
        console.log(`✅ ${name}`);
        testsPassed++;
      }).catch(err => {
        console.log(`❌ ${name}: ${err.message}`);
        testsFailed++;
      }) : (console.log(`✅ ${name}`), testsPassed++);
    } else {
      console.log(`❌ ${name}`);
      testsFailed++;
    }
  } catch (err) {
    console.log(`❌ ${name}: ${err.message}`);
    testsFailed++;
  }
}

// The ONLY trusted mint public key embedded in the wallet
const TRUSTED_MINT_PUBLIC_KEY = {
  "key_ops": ["verify"],
  "ext": true,
  "kty": "EC",
  "x": "yFqzw0WrwC3O5oc0nSEbH94Ybb0_55GsGV7BB1vAlnM",
  "y": "tV4VDNnDQIToL94c5Ma1wi8jv2gMhCk6NTYWeosV3xU",
  "crv": "P-256"
};

async function runMintSecurityTests() {
  console.log('1️⃣  COUNTERFEIT BILL CREATION ATTEMPTS\n');

  // Test 1: Attacker creates their own key pair
  await test('Rejects bill signed with attacker\'s own key pair', async () => {
    const { subtle } = crypto.webcrypto;
    
    // Attacker generates their own ECDSA key pair
    const attackerKeyPair = await subtle.generateKey(
      { name: 'ECDSA', namedCurve: 'P-256' },
      true,
      ['sign', 'verify']
    );
    
    // Attacker creates a counterfeit bill
    const counterfeitBill = {
      serialNumber: 'COUNTERFEIT-001',
      denomination: 1000000, // Attacker tries to mint $1 million
      timestamp: Date.now()
    };
    
    // Attacker signs it with their own private key
    const encoder = new TextEncoder();
    const dataToSign = encoder.encode(JSON.stringify({
      serialNumber: counterfeitBill.serialNumber,
      denomination: counterfeitBill.denomination,
      timestamp: counterfeitBill.timestamp
    }));
    
    const signature = await subtle.sign(
      { name: 'ECDSA', hash: { name: 'SHA-256' } },
      attackerKeyPair.privateKey,
      dataToSign
    );
    
    counterfeitBill.signature = Buffer.from(signature).toString('base64');
    
    // Export attacker's public key
    const attackerPublicKey = await subtle.exportKey('jwk', attackerKeyPair.publicKey);
    counterfeitBill.publicKey = attackerPublicKey;
    
    // Wallet MUST reject this because it only trusts the embedded mint key
    const result = await verifier.verifyBill(counterfeitBill);
    
    return result.valid === false && result.reason.includes('signature');
  });

  // Test 2: Reverse engineered bill with modified denomination
  await test('Rejects reverse-engineered bill with modified denomination', async () => {
    // Attacker copies a real bill and tries to modify it
    const stolenBill = {
      serialNumber: 'CC-STOLEN-001',
      denomination: 10, // Original denomination
      timestamp: Date.now(),
      signature: 'MEUCIQDxK8h9vZJ3mR2L4nF8pW5kT6vY3qX9sE1jU7cN2wH5gQIgV8dR3kP2mL7nJ9sT4vW6xY1zE5hN8qF2cU7jK3pB9wA=',
      publicKey: TRUSTED_MINT_PUBLIC_KEY
    };
    
    // Attacker changes denomination to $1000
    stolenBill.denomination = 1000;
    
    // Signature is now invalid because denomination changed
    const result = await verifier.verifyBill(stolenBill);
    
    return result.valid === false && result.reason.includes('signature');
  });

  // Test 3: Copied bill from another wallet
  await test('Rejects physically copied bill (duplicate fingerprint)', async () => {
    // Legitimate bill in Wallet A
    const originalBill = {
      serialNumber: 'CC-ORIGINAL-001',
      denomination: 50,
      timestamp: Date.now(),
      fingerprint: 'aaaa1111bbbb2222cccc3333dddd4444eeee5555ffff6666gggg7777hhhh8888',
      signature: 'valid-signature',
      publicKey: TRUSTED_MINT_PUBLIC_KEY
    };
    
    // Register the original bill's fingerprint
    verifier.registerFingerprint(originalBill.fingerprint, originalBill.serialNumber);
    
    // Attacker copies the bill file to their wallet (Wallet B)
    const copiedBill = { ...originalBill };
    copiedBill.serialNumber = 'CC-COPY-001'; // Try to hide it
    
    // Wallet B MUST detect duplicate fingerprint
    const result = await verifier.verifyBill(copiedBill);
    
    return result.valid === false && result.reason.includes('fingerprint');
  });

  console.log('\n2️⃣  OFFLINE LAN TRANSFER SECURITY\n');

  // Test 4: Bill sent offline on LAN - sender cannot reuse
  await test('Offline LAN transfer: Sender cannot reuse sent bill', async () => {
    // Computer A sends bill to Computer B over LAN
    const billToSend = {
      serialNumber: 'LAN-TRANSFER-001',
      denomination: 100,
      timestamp: Date.now(),
      fingerprint: 'lan1111transfer2222secure3333offline4444network5555local6666area7777test',
      signature: 'test-sig',
      publicKey: TRUSTED_MINT_PUBLIC_KEY
    };
    
    // Sender's wallet marks as spent
    verifier.markAsSpent(billToSend.serialNumber);
    
    // Sender deletes bill from their wallet
    verifier.deleteBill(billToSend.serialNumber);
    
    // Sender tries to re-import the bill they just sent
    const reImportAttempt = await verifier.verifyBill(billToSend);
    
    // MUST be rejected due to spent list
    return reImportAttempt.valid === false && 
           reImportAttempt.reason.includes('already spent');
  });

  // Test 5: Recipient on different computer can accept
  await test('Offline LAN transfer: Recipient can accept bill', async () => {
    // Simulate Computer B (fresh wallet instance)
    const recipientVerifier = new BillVerifier();
    
    const receivedBill = {
      serialNumber: 'LAN-RECEIVE-001',
      denomination: 75,
      timestamp: Date.now(),
      fingerprint: 'receive1111offline2222transfer3333secure4444network5555private6666test',
      signature: 'test-sig-2',
      publicKey: TRUSTED_MINT_PUBLIC_KEY
    };
    
    // Recipient's wallet has never seen this bill
    const isSpent = recipientVerifier.checkSpentList(receivedBill.serialNumber);
    const hasFingerprint = recipientVerifier.checkFingerprint(receivedBill.fingerprint);
    
    // Should not be in spent list or fingerprint registry
    return !isSpent && !hasFingerprint;
  });

  // Test 6: Double-spend attempt on LAN
  await test('Offline LAN: Double-spend attempt blocked', async () => {
    // Attacker sends same bill to two people on LAN
    const duplicateBill = {
      serialNumber: 'LAN-DOUBLESPEND-001',
      denomination: 200,
      timestamp: Date.now()
    };
    
    // First recipient accepts
    verifier.markAsSpent(duplicateBill.serialNumber);
    
    // Second recipient tries to accept same bill
    const secondAttempt = await verifier.verifyBill(duplicateBill);
    
    return secondAttempt.valid === false && 
           secondAttempt.reason.includes('already spent');
  });

  console.log('\n3️⃣  CRITICAL: BILLS REQUIRE VALID MINT SIGNATURE\n');

  // Test 7: No bill can exist without proper mint signature
  await test('CRITICAL: Cannot create bill without mint private key', async () => {
    // This is the fundamental security guarantee
    // WITHOUT the mint's private key, NO valid signature can be created
    
    const attemptedBill = {
      serialNumber: 'IMPOSSIBLE-001',
      denomination: 999999,
      timestamp: Date.now(),
      signature: 'fake-signature-no-private-key',
      publicKey: TRUSTED_MINT_PUBLIC_KEY
    };
    
    // Wallet MUST reject - signature verification will fail
    const result = await verifier.verifyBill(attemptedBill);
    
    return result.valid === false;
  });

  // Test 8: Wallet only trusts embedded mint key
  await test('CRITICAL: Wallet ignores bill-provided public key', async () => {
    const { subtle } = crypto.webcrypto;
    
    // Attacker creates their own key pair
    const fakeKeyPair = await subtle.generateKey(
      { name: 'ECDSA', namedCurve: 'P-256' },
      true,
      ['sign', 'verify']
    );
    
    const maliciousBill = {
      serialNumber: 'MALICIOUS-001',
      denomination: 5000,
      timestamp: Date.now()
    };
    
    // Sign with attacker's key
    const encoder = new TextEncoder();
    const data = encoder.encode(JSON.stringify({
      serialNumber: maliciousBill.serialNumber,
      denomination: maliciousBill.denomination,
      timestamp: maliciousBill.timestamp
    }));
    
    const sig = await subtle.sign(
      { name: 'ECDSA', hash: { name: 'SHA-256' } },
      fakeKeyPair.privateKey,
      data
    );
    
    maliciousBill.signature = Buffer.from(sig).toString('base64');
    
    // Include attacker's public key in bill
    const attackerPubKey = await subtle.exportKey('jwk', fakeKeyPair.publicKey);
    maliciousBill.publicKey = attackerPubKey;
    
    // Wallet MUST use embedded mint key, NOT the bill's key
    // This will fail because signature was created with different key
    const result = await verifier.verifyBill(maliciousBill);
    
    return result.valid === false;
  });

  console.log('\n4️⃣  OFFLINE COMPUTER ISOLATION TESTS\n');

  // Test 9: Completely offline computers
  await test('Offline computers: No network access required', () => {
    // All verification operations work with local files only
    const usesNetwork = false; // Wallet never makes network calls
    const usesLocalFiles = fs.existsSync(verifier.dataPath);
    const usesEmbeddedKey = verifier.trustedMintKey !== null;
    
    return !usesNetwork && usesLocalFiles && usesEmbeddedKey;
  });

  // Test 10: Air-gapped security
  await test('Air-gapped security: Pre-shared keys enable verification', () => {
    // The mint's public key is embedded in the wallet code
    // No online verification needed
    const hasTrustedKey = verifier.trustedMintKey.x === TRUSTED_MINT_PUBLIC_KEY.x;
    const canVerifyOffline = typeof verifier.verifySignature === 'function';
    
    return hasTrustedKey && canVerifyOffline;
  });

  console.log('\n5️⃣  DEVELOPER WALLET SECURITY\n');

  // Test 11: Manually placed bill in dev wallet
  await test('Dev wallet: Manually copied bill file is validated', async () => {
    // Developer copies a bill JSON file into ~/.bytecash/bills/
    const manualBill = {
      serialNumber: 'DEV-MANUAL-001',
      denomination: 25,
      timestamp: Date.now(),
      signature: 'invalid-manual-signature',
      publicKey: TRUSTED_MINT_PUBLIC_KEY
    };
    
    // Save it directly to bills directory
    verifier.saveBill(manualBill);
    
    // When wallet loads, it MUST verify signature
    const result = await verifier.verifyBill(manualBill);
    
    // Invalid signature = rejected
    return result.valid === false;
  });

  // Test 12: Spent bill cannot be unspent by editing files
  await test('Dev wallet: Cannot unspend bill by editing spent_list.json', async () => {
    const testBill = {
      serialNumber: 'UNSPEND-ATTEMPT-001',
      denomination: 50,
      timestamp: Date.now()
    };
    
    // Mark as spent
    verifier.markAsSpent(testBill.serialNumber);
    
    // Developer tries to manually remove from spent list
    // (We won't actually do this, but verify the check works)
    const isStillSpent = verifier.checkSpentList(testBill.serialNumber);
    
    // Even if they edit the file, verification checks spent list
    const result = await verifier.verifyBill(testBill);
    
    return isStillSpent && result.valid === false;
  });

  console.log('\n═════════════════════════════════════════════════════════');
  console.log(`\n📊 MINT SECURITY TEST RESULTS:`);
  console.log(`   ✅ Passed: ${testsPassed}`);
  console.log(`   ❌ Failed: ${testsFailed}`);
  console.log(`   Total: ${testsPassed + testsFailed}`);

  if (testsFailed === 0) {
    console.log('\n🎉 ALL MINT SECURITY TESTS PASSED!');
    console.log('\n✅ CRITICAL SECURITY GUARANTEES VERIFIED:');
    console.log('   • Bills CANNOT be minted without the mint\'s private key');
    console.log('   • Wallet ONLY trusts the embedded mint public key');
    console.log('   • Counterfeit bills are immediately detected');
    console.log('   • Reverse-engineered bills are rejected');
    console.log('   • Physically copied bills are blocked');
    console.log('   • Offline LAN transfers are secure');
    console.log('   • Double-spending is prevented offline');
    console.log('   • No network access required for verification');
    console.log('   • Developer wallets validate all bills\n');
    return true;
  } else {
    console.log(`\n⚠️  ${testsFailed} security test(s) failed\n`);
    console.log('🚨 CRITICAL: Security vulnerabilities detected!\n');
    return false;
  }
}

runMintSecurityTests().then(success => {
  process.exit(success ? 0 : 1);
}).catch(err => {
  console.error('Test error:', err);
  process.exit(1);
});
