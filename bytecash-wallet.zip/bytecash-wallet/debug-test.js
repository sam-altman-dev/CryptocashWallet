const BillVerifier = require('./crypto');
const verifier = new BillVerifier();

const validBill = {
  serialNumber: "CC-TEST-DEBUG",
  denomination: 50,
  timestamp: Date.now(),
  signature: "MEUCIQDxK8h9vZJ3mR2L4nF8pW5kT6vY3qX9sE1jU7cN2wH5gQIgV8dR3kP2mL7nJ9sT4vW6xY1zE5hN8qF2cU7jK3pB9wA=",
  publicKey: {
    "key_ops": ["verify"],
    "ext": true,
    "kty": "EC",
    "x": "yFqzw0WrwC3O5oc0nSEbH94Ybb0_55GsGV7BB1vAlnM",
    "y": "tV4VDNnDQIToL94c5Ma1wi8jv2gMhCk6NTYWeosV3xU",
    "crv": "P-256"
  },
  fingerprint: "a1b2c3d4e5f6789012345678901234567890abcdef1234567890abcdef123456",
  quantumSalt: "q1w2e3r4t5y6u7i8o9p0a1s2d3f4g5h6j7k8l9z0x1c2v3b4n5m6q7w8e9r0t1y2u3i4o5p6a7s8d9f0g1h2j3k4l5z6x7c8v9b0n1m2",
  tamperSeal: "MEQCIFxY3kP8mL6nJ7sT2vW4xY9zE3hN6qF0cU5jK1pB7wAQAiB9R2kM5L4nH8sS3vV5xW8zD2hM7qE1cT6jJ0pA9vBwQ=="
};

console.log('Testing exportWallet():');
const exported = verifier.exportWallet();
console.log('Result:', exported);
console.log('Has version?', !!exported.version);
console.log('Has bills?', !!exported.bills);
console.log('Has spentList?', !!exported.spentList);
console.log('Test passes?', exported.version && exported.bills && exported.spentList);

console.log('\nTesting getSecurityChecklist():');
const checklist = verifier.getSecurityChecklist(validBill);
console.log('Result:', checklist);
console.log('Has signature?', !!checklist.signature);
console.log('Has doubleSpend?', !!checklist.doubleSpend);
console.log('Has fingerprint?', !!checklist.fingerprint);
console.log('Test 1 passes?', checklist.signature && checklist.doubleSpend && checklist.fingerprint);
console.log('Has all 6?', checklist.signature && checklist.doubleSpend && checklist.fingerprint && checklist.tamperSeal && checklist.quantumSalt && checklist.offlineMode);
