
const BillVerifier = require('./crypto');
const fs = require('fs');
const path = require('path');

console.log('🧪 Testing Offline Bill Sending with Double-Spend Prevention\n');
console.log('=========================================\n');

const verifier = new BillVerifier();

// Test Scenario:
// 1. Import a bill into wallet
// 2. Send the bill (export + mark spent + delete)
// 3. Verify bill is gone from wallet
// 4. Try to import the SAME bill again (should fail - already spent)
// 5. Verify only the LATEST copy works (offline double-spend prevention)

async function testOfflineSendProtection() {
  console.log('📦 Step 1: Import a test bill\n');
  
  const testBill = {
    serialNumber: 'OFFLINE-SEND-TEST-001',
    denomination: 50,
    timestamp: Date.now(),
    signature: "MEUCIQDxK8h9vZJ3mR2L4nF8pW5kT6vY3qX9sE1jU7cN2wH5gQIgV8dR3kP2mL7nJ9sT4vW6xY1zE5hN8qF2cU7jK3pB9wA=",
    publicKey: {
      "key_ops": ["verify"],
      "ext": true,
      "kty": "EC",
      "x": "yFqzw0WrwC3O5oc0nSEbH94Ybb0_55GsGV7BB1vAlnM",
      "y": "tV4VDNnDQIToL94c5Ma1wi8jv2gMhCk6NTYWeosV3xU",
      "crv": "P-256"
    },
    fingerprint: "offline-test-fingerprint-001",
    version: "1.0"
  };

  // Accept bill into wallet
  const acceptResult = await verifier.acceptBill(testBill);
  console.log(`✅ Bill imported: ${acceptResult.success}`);
  console.log(`   Serial: ${testBill.serialNumber}`);
  console.log(`   Balance before send: $${verifier.getTotalBalance()}\n`);

  console.log('📤 Step 2: Send the bill (simulate transfer)\n');
  
  // Simulate sending: mark as spent FIRST, then delete
  verifier.markAsSpent(testBill.serialNumber);
  console.log('✅ Bill marked as spent (prevents double-spend)');
  
  verifier.deleteBill(testBill.serialNumber);
  console.log('✅ Bill deleted from wallet (no copy retained)\n');

  console.log('🔍 Step 3: Verify bill is gone from wallet\n');
  const billsAfterSend = verifier.getAllBills();
  const billExists = billsAfterSend.find(b => b.serialNumber === testBill.serialNumber);
  console.log(`   Bill in wallet: ${billExists ? '❌ STILL EXISTS (SECURITY BREACH!)' : '✅ Deleted'}`);
  console.log(`   Balance after send: $${verifier.getTotalBalance()}`);
  console.log(`   Is marked as spent: ${verifier.checkSpentList(testBill.serialNumber) ? '✅ Yes' : '❌ No'}\n`);

  console.log('🚫 Step 4: Try to re-import the SAME bill (double-spend attempt)\n');
  const reImportResult = await verifier.acceptBill(testBill);
  console.log(`   Re-import succeeded: ${reImportResult.success ? '❌ SECURITY FAILURE!' : '✅ Blocked'}`);
  console.log(`   Reason: ${reImportResult.verification.reason}\n`);

  console.log('🔒 Step 5: Verify offline double-spend prevention\n');
  const spentList = verifier.getSpentList();
  const isInSpentList = spentList.includes(testBill.serialNumber);
  console.log(`   Bill in spent list: ${isInSpentList ? '✅ Yes' : '❌ No (CRITICAL BUG!)'}`);
  console.log(`   Offline verification: ✅ No internet required\n`);

  console.log('=========================================\n');
  
  if (!billExists && isInSpentList && !reImportResult.success) {
    console.log('🎉 OFFLINE SEND PROTECTION: ✅ WORKING CORRECTLY\n');
    console.log('Security guarantees:');
    console.log('  ✅ Sent bills are deleted from wallet');
    console.log('  ✅ Spent list prevents double-spending');
    console.log('  ✅ Re-importing same bill is blocked');
    console.log('  ✅ Works completely offline\n');
    return true;
  } else {
    console.log('❌ SECURITY FAILURE DETECTED\n');
    if (billExists) console.log('  ❌ Bill still in wallet after sending');
    if (!isInSpentList) console.log('  ❌ Bill not in spent list');
    if (reImportResult.success) console.log('  ❌ Double-spend not prevented');
    return false;
  }
}

testOfflineSendProtection().catch(console.error);
