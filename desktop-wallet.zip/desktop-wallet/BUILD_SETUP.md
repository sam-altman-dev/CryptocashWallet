# Bytecash Electrum Desktop Wallet - Build Setup Guide

## Overview

The Bytecash Electrum desktop wallet is built using Electron and electron-builder. This guide explains how to build the application for Windows, macOS, and Linux platforms.

## Prerequisites

### All Platforms
- Node.js 20.x or later
- npm 8.x or later
- Git

### Platform-Specific Requirements

#### Windows Builds
**Building on Windows:**
- Windows 10 or later
- No additional requirements

**Building on Linux (cross-platform):**
- Wine 2.0+ (required for Windows builds on Linux)
- On NixOS: `wineWowPackages.stable` package
- Mono (for certain Windows installers)

**Building on macOS:**
- Requires Xcode command line tools

#### macOS Builds
**Building on macOS:**
- macOS 10.13+ 
- Xcode command line tools: `xcode-select --install`

**Building on Linux (limited):**
- Can create ZIP archives only
- Cannot create DMG files (requires macOS)

#### Linux Builds
**Can be built on any platform:**
- No special requirements
- Builds AppImage and DEB packages

## Installation

1. Navigate to the desktop-wallet directory:
```bash
cd CryptoBillSecure/desktop-wallet
```

2. Install dependencies:
```bash
npm install
```

## Build Commands

### Quick Build Commands

```bash
# Build for current platform
npm run build

# Build for Windows
npm run build:win

# Build for macOS
npm run build:mac

# Build for Linux
npm run build:linux
```

### Advanced Build Commands

```bash
# Build Windows portable executable (no installer)
npx electron-builder --win --x64 portable

# Build macOS ZIP only (no DMG)
npx electron-builder --mac --x64 zip

# Build Linux AppImage only
npx electron-builder --linux --x64 AppImage

# Build for all platforms (requires proper setup)
npx electron-builder --win --mac --linux
```

## Build Outputs

### Windows
**Location:** `dist/`

**Files created (requires Windows or Wine):**
- `Bytecash Electrum Setup 1.0.0.exe` - NSIS installer (requires Wine on Linux)
- `Bytecash Electrum 1.0.0.exe` - Portable executable (requires Wine on Linux)
- `Bytecash Electrum-1.0.0-win.zip` - Portable ZIP archive (requires Wine on Linux)
- `win-unpacked/` - Unpacked application directory

**Target architectures:** x64 (64-bit)

**Note:** All Windows builds require Wine when building on Linux/macOS. Build on Windows natively for best results.

### macOS
**Location:** `dist/`

**Files created (requires macOS):**
- `Bytecash Electrum-1.0.0.dmg` - Intel (x64) disk image
- `Bytecash Electrum-1.0.0-mac.zip` - Intel (x64) ZIP archive
- `Bytecash Electrum-1.0.0-arm64.dmg` - Apple Silicon (arm64) disk image
- `Bytecash Electrum-1.0.0-arm64-mac.zip` - Apple Silicon (arm64) ZIP
- `mac/` - macOS application bundle

**Target architectures:** Separate builds for x64 (Intel) and arm64 (Apple Silicon)

**Note:** DMG creation requires macOS. Building on Linux will fail with dmg-license errors. Configuration creates separate architecture-specific binaries, not universal binaries.

### Linux
**Location:** `dist/`

**Files created:**
- `Bytecash Electrum-1.0.0.AppImage` - Universal Linux application (100MB)
- `bytecash-electrum_1.0.0_amd64.deb` - Debian/Ubuntu package (70MB)
- `linux-unpacked/` - Unpacked application directory

**Target architectures:** x64 (64-bit)

## Successfully Built Packages

✅ **Linux Builds (Verified on NixOS Linux)**
- `Bytecash Electrum-1.0.0.AppImage` - 100MB
- `bytecash-electrum_1.0.0_amd64.deb` - 70MB

These were successfully built and are ready for distribution.

⚠️ **Windows Builds (Requires Wine or Native Windows)**
- Cannot be built on Linux without Wine properly configured
- Wine detection issues on NixOS prevented Windows builds
- Recommended: Build on Windows natively or use CI/CD

⚠️ **macOS Builds (Requires macOS)**
- Cannot be built on Linux (requires macOS-specific tools)
- Recommended: Build on macOS or use macOS CI/CD runners

## Cross-Platform Building

### Building Windows on Linux (NixOS)

On NixOS, you need to install Wine packages:

```nix
# Add to your configuration.nix or install via nix-shell
wineWowPackages.stable
mono
```

**Known Limitation:** Wine integration with electron-builder on NixOS can be challenging. For production Windows builds, it's recommended to:
1. Build on a native Windows machine
2. Use GitHub Actions or CI/CD with official electron-builder Docker images
3. Use the official `electronuserland/builder:wine` Docker image

### Building macOS on Linux

**Limitations:**
- Cannot create DMG files (requires macOS)
- Can only create ZIP archives
- Code signing requires macOS

For production macOS builds, use a macOS machine or macOS CI/CD runners.

## Package Configuration

### package.json Build Configuration

```json
{
  "build": {
    "appId": "com.bytecash.electrum",
    "productName": "Bytecash Electrum",
    "directories": {
      "output": "dist"
    },
    "win": {
      "target": ["nsis", "portable", "zip"],
      "icon": "assets/icon.ico"
    },
    "mac": {
      "target": [
        {"target": "dmg", "arch": ["x64", "arm64"]},
        {"target": "zip", "arch": ["x64", "arm64"]}
      ],
      "category": "public.app-category.finance",
      "icon": "assets/icon.icns"
    },
    "linux": {
      "target": ["AppImage", "deb"],
      "category": "Finance",
      "icon": "assets/icon.png"
    },
    "nsis": {
      "oneClick": false,
      "allowToChangeInstallationDirectory": true,
      "createDesktopShortcut": true,
      "createStartMenuShortcut": true
    }
  }
}
```

## Icon Assets

Place platform-specific icons in `assets/`:
- `icon.png` - 512x512 PNG for Linux
- `icon.ico` - Windows icon (256x256 or multiple sizes)
- `icon.icns` - macOS icon (512x512 or multiple sizes)

Currently using default Electron icons. Custom icons should be added before production release.

## Development

### Running in Development Mode

```bash
# Start with development tools
npm run dev

# Or regular start
npm start
```

This opens the application with:
- DevTools enabled (in dev mode)
- Hot reload capabilities
- Debug logging

## Troubleshooting

### Wine Issues on Linux
**Error:** "wine is required"

**Solutions:**
1. Install Wine: `wineWowPackages.stable` (NixOS) or `wine` (Ubuntu/Debian)
2. Verify Wine is in PATH: `which wine`
3. Use Docker with `electronuserland/builder:wine` image
4. Build on Windows natively

### DMG Creation Fails on Linux
**Error:** "Cannot find module 'dmg-license'"

**Solution:** This is expected. DMG files can only be created on macOS. Build ZIP archives instead or use macOS for building.

### Missing Dependencies
**Error:** Module not found errors

**Solution:**
```bash
rm -rf node_modules package-lock.json
npm install
```

## CI/CD Recommendations

### GitHub Actions Example

```yaml
name: Build
on: [push]
jobs:
  build-windows:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm install
      - run: npm run build:win
      
  build-macos:
    runs-on: macos-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm install
      - run: npm run build:mac
      
  build-linux:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm install
      - run: npm run build:linux
```

## Distribution

### Linux
- **AppImage:** Universal, works on all distros, no installation required
- **DEB:** For Debian/Ubuntu-based systems, install with `sudo dpkg -i bytecash-electrum_1.0.0_amd64.deb`

### Windows
- **Installer:** Double-click to install
- **Portable:** Extract ZIP and run executable

### macOS
- **DMG:** Drag to Applications folder
- **ZIP:** Extract and move to Applications

## Security Notes

1. **Code Signing:** Configure code signing certificates for production builds
2. **Auto-updates:** Configure using electron-updater for automatic updates
3. **Notarization:** macOS builds should be notarized for distribution

## Support

For build issues:
1. Check this documentation
2. Review electron-builder documentation: https://www.electron.build
3. Verify all dependencies are installed
4. Try building on the native platform

---

**Version:** 1.0.0  
**Last Updated:** October 2025  
**Build System:** Electron 28.0.0, electron-builder 24.9.0
