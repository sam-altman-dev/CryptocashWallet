const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

// TRUSTED MINT PUBLIC KEY - Embedded in application
// This is the ONLY public key trusted for bill verification
// Bills must be signed by the corresponding private key
const TRUSTED_MINT_PUBLIC_KEY = {
  "key_ops": ["verify"],
  "ext": true,
  "kty": "EC",
  "x": "yFqzw0WrwC3O5oc0nSEbH94Ybb0_55GsGV7BB1vAlnM",
  "y": "tV4VDNnDQIToL94c5Ma1wi8jv2gMhCk6NTYWeosV3xU",
  "crv": "P-256"
};

class BillVerifier {
  constructor() {
    this.dataPath = path.join(
      require('os').homedir(),
      '.bytecash'
    );
    this.spentListPath = path.join(this.dataPath, 'spent_list.json');
    this.billsPath = path.join(this.dataPath, 'bills');
    this.fingerprintsPath = path.join(this.dataPath, 'fingerprints.json');
    this.trustedMintKey = TRUSTED_MINT_PUBLIC_KEY;
    
    this.ensureDirectoriesExist();
  }

  ensureDirectoriesExist() {
    // Create base directory
    if (!fs.existsSync(this.dataPath)) {
      fs.mkdirSync(this.dataPath, { recursive: true });
    }
    
    // Create bills directory
    if (!fs.existsSync(this.billsPath)) {
      fs.mkdirSync(this.billsPath, { recursive: true });
    }
    
    // Create spent list
    if (!fs.existsSync(this.spentListPath)) {
      fs.writeFileSync(this.spentListPath, JSON.stringify([]));
    }
    
    // Create fingerprints registry
    if (!fs.existsSync(this.fingerprintsPath)) {
      fs.writeFileSync(this.fingerprintsPath, JSON.stringify({}));
    }
  }

  // ============= SPENT LIST OPERATIONS =============

  getSpentList() {
    const data = fs.readFileSync(this.spentListPath, 'utf8');
    return JSON.parse(data);
  }

  markAsSpent(serialNumber) {
    const spentList = this.getSpentList();
    
    if (!spentList.includes(serialNumber)) {
      spentList.push(serialNumber);
      fs.writeFileSync(this.spentListPath, JSON.stringify(spentList, null, 2));
    }
  }

  checkSpentList(serialNumber) {
    return this.getSpentList().includes(serialNumber);
  }

  // ============= FINGERPRINT OPERATIONS =============

  getFingerprintRegistry() {
    const data = fs.readFileSync(this.fingerprintsPath, 'utf8');
    return JSON.parse(data);
  }

  checkFingerprint(fingerprint) {
    const registry = this.getFingerprintRegistry();
    return registry[fingerprint] !== undefined;
  }

  registerFingerprint(fingerprint, serialNumber) {
    const registry = this.getFingerprintRegistry();
    registry[fingerprint] = {
      serialNumber,
      timestamp: new Date().toISOString()
    };
    fs.writeFileSync(this.fingerprintsPath, JSON.stringify(registry, null, 2));
  }

  // ============= BILL STORAGE OPERATIONS =============

  saveBill(billData) {
    const filename = `${billData.serialNumber}.json`;
    const filepath = path.join(this.billsPath, filename);
    fs.writeFileSync(filepath, JSON.stringify(billData, null, 2));
  }

  getAllBills() {
    const bills = [];
    const files = fs.readdirSync(this.billsPath);
    
    for (const file of files) {
      if (file.endsWith('.json')) {
        const filepath = path.join(this.billsPath, file);
        const data = fs.readFileSync(filepath, 'utf8');
        bills.push(JSON.parse(data));
      }
    }
    
    return bills;
  }

  getTotalBalance() {
    const bills = this.getAllBills();
    return bills.reduce((sum, bill) => sum + bill.denomination, 0);
  }

  deleteBill(serialNumber) {
    const filename = `${serialNumber}.json`;
    const filepath = path.join(this.billsPath, filename);
    if (fs.existsSync(filepath)) {
      fs.unlinkSync(filepath);
    }
  }

  // ============= CRYPTOGRAPHIC VERIFICATION =============

  async verifySignature(billData) {
    try {
      const { subtle } = crypto.webcrypto;
      
      // SECURITY: Use TRUSTED mint public key, NOT the bill-provided key
      // This prevents attackers from creating counterfeit bills with their own keys
      const publicKey = await subtle.importKey(
        'jwk',
        this.trustedMintKey,
        {
          name: 'ECDSA',
          namedCurve: 'P-256',
        },
        false,
        ['verify']
      );

      // Create data to verify
      const dataToVerify = JSON.stringify({
        serialNumber: billData.serialNumber,
        denomination: billData.denomination,
        timestamp: billData.timestamp,
      });

      const encoder = new TextEncoder();
      const dataBuffer = encoder.encode(dataToVerify);
      const signatureBuffer = Buffer.from(billData.signature, 'base64');

      // Verify
      const isValid = await subtle.verify(
        {
          name: 'ECDSA',
          hash: { name: 'SHA-256' },
        },
        publicKey,
        signatureBuffer,
        dataBuffer
      );

      return isValid;
    } catch (error) {
      console.error('Signature verification error:', error);
      return false;
    }
  }

  async verifyTamperSeal(billData) {
    if (!billData.tamperSeal || !billData.fingerprint) {
      return { valid: false, reason: 'Missing tamper seal or fingerprint' };
    }

    try {
      const { subtle } = crypto.webcrypto;
      
      // SECURITY: Use TRUSTED mint public key for tamper seal verification
      const publicKey = await subtle.importKey(
        'jwk',
        this.trustedMintKey,
        {
          name: 'ECDSA',
          namedCurve: 'P-256',
        },
        false,
        ['verify']
      );

      // Recreate seal data
      const billDataHash = JSON.stringify({
        serialNumber: billData.serialNumber,
        denomination: billData.denomination,
        timestamp: billData.timestamp,
      });

      const sealData = JSON.stringify({
        billData: billDataHash,
        fingerprint: billData.fingerprint,
        timestamp: billData.sealTimestamp || Date.now()
      });

      const encoder = new TextEncoder();
      const dataBuffer = encoder.encode(sealData);
      const sealBuffer = Buffer.from(billData.tamperSeal, 'base64');

      // Verify seal
      const isValid = await subtle.verify(
        {
          name: 'ECDSA',
          hash: { name: 'SHA-256' },
        },
        publicKey,
        sealBuffer,
        dataBuffer
      );

      if (!isValid) {
        return { valid: false, reason: 'Tamper seal verification failed - bill may have been tampered with' };
      }

      return { valid: true, reason: 'Tamper seal verified' };
    } catch (error) {
      console.error('Tamper seal verification error:', error);
      return { valid: false, reason: 'Tamper seal verification error' };
    }
  }

  // ============= COMPLETE BILL VERIFICATION =============

  async verifyBill(billData) {
    // 1. Verify signature
    const signatureValid = await this.verifySignature(billData);
    
    if (!signatureValid) {
      return {
        valid: false,
        reason: 'Invalid cryptographic signature - bill may be counterfeit',
      };
    }

    // 2. Check spent list (double-spending prevention)
    if (this.checkSpentList(billData.serialNumber)) {
      return {
        valid: false,
        reason: 'Bill already spent - duplicate detected (DOUBLE-SPEND PREVENTED)',
      };
    }

    // 3. Check fingerprint (prevents physical copying)
    if (billData.fingerprint) {
      if (this.checkFingerprint(billData.fingerprint)) {
        const registry = this.getFingerprintRegistry();
        const existing = registry[billData.fingerprint];
        return {
          valid: false,
          reason: `Duplicate fingerprint detected - bill is a clone of ${existing.serialNumber} (CLONE PREVENTED)`,
        };
      }
    }

    // 4. Verify tamper seal if present
    if (billData.tamperSeal) {
      const sealCheck = await this.verifyTamperSeal(billData);
      if (!sealCheck.valid) {
        return {
          valid: false,
          reason: sealCheck.reason,
        };
      }
    }

    // 5. Verify quantum-resistant salt if present (future-proofing)
    if (billData.quantumSalt) {
      if (billData.quantumSalt.length !== 128) {
        return {
          valid: false,
          reason: 'Invalid quantum-resistant salt - insufficient entropy',
        };
      }
    }

    return {
      valid: true,
      reason: 'Bill is authentic, not spent, and has not been tampered with',
    };
  }

  async acceptBill(billData) {
    const verification = await this.verifyBill(billData);
    
    if (verification.valid) {
      // Mark as spent
      this.markAsSpent(billData.serialNumber);
      
      // Register fingerprint
      if (billData.fingerprint) {
        this.registerFingerprint(billData.fingerprint, billData.serialNumber);
      }
      
      // Save bill to storage
      this.saveBill(billData);
      
      return { success: true, verification };
    }
    
    return { success: false, verification };
  }

  // ============= SECURITY CHECKLIST =============

  getSecurityChecklist(billData) {
    return {
      signature: '✓ ECDSA P-256 cryptographic signature',
      doubleSpend: this.checkSpentList(billData.serialNumber) 
        ? '✗ Bill already spent (REJECTED)' 
        : '✓ No double-spend detected',
      fingerprint: billData.fingerprint 
        ? (this.checkFingerprint(billData.fingerprint) 
          ? '✗ Duplicate fingerprint (CLONE DETECTED)' 
          : '✓ Unique fingerprint verified')
        : '⚠ No fingerprint (legacy bill)',
      tamperSeal: billData.tamperSeal 
        ? '✓ Tamper seal present' 
        : '⚠ No tamper seal (legacy bill)',
      quantumSalt: billData.quantumSalt 
        ? '✓ Quantum-resistant salt (64 bytes)' 
        : '⚠ No quantum salt (legacy bill)',
      offlineMode: '✓ Complete offline verification',
    };
  }

  // ============= EXPORT/IMPORT WALLET =============

  exportWallet() {
    const bills = this.getAllBills();
    const spentList = this.getSpentList();
    const fingerprints = this.getFingerprintRegistry();

    return {
      version: '1.0',
      exportDate: new Date().toISOString(),
      bills,
      spentList,
      fingerprints,
      totalBalance: this.getTotalBalance(),
      billCount: bills.length,
    };
  }

  importWallet(walletData) {
    if (!walletData.version || !walletData.bills) {
      throw new Error('Invalid wallet data format');
    }

    // Import bills
    for (const bill of walletData.bills) {
      this.saveBill(bill);
    }

    // Import spent list
    if (walletData.spentList) {
      fs.writeFileSync(this.spentListPath, JSON.stringify(walletData.spentList, null, 2));
    }

    // Import fingerprints
    if (walletData.fingerprints) {
      fs.writeFileSync(this.fingerprintsPath, JSON.stringify(walletData.fingerprints, null, 2));
    }

    return {
      billsImported: walletData.bills.length,
      totalBalance: this.getTotalBalance(),
    };
  }
}

module.exports = BillVerifier;
