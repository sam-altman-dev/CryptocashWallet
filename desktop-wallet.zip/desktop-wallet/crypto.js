
const crypto = require('crypto');

class BillVerifier {
  constructor() {
    this.spentListPath = require('path').join(
      require('os').homedir(),
      '.bytecash',
      'spent_list.json'
    );
    this.ensureSpentListExists();
  }

  ensureSpentListExists() {
    const fs = require('fs');
    const path = require('path');
    const dir = path.dirname(this.spentListPath);
    
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    
    if (!fs.existsSync(this.spentListPath)) {
      fs.writeFileSync(this.spentListPath, JSON.stringify([]));
    }
  }

  getSpentList() {
    const fs = require('fs');
    const data = fs.readFileSync(this.spentListPath, 'utf8');
    return JSON.parse(data);
  }

  markAsSpent(serialNumber) {
    const fs = require('fs');
    const spentList = this.getSpentList();
    
    if (!spentList.includes(serialNumber)) {
      spentList.push(serialNumber);
      fs.writeFileSync(this.spentListPath, JSON.stringify(spentList, null, 2));
    }
  }

  checkSpentList(serialNumber) {
    return this.getSpentList().includes(serialNumber);
  }

  async verifySignature(billData) {
    try {
      const { subtle } = crypto.webcrypto;
      
      // Import public key
      const publicKey = await subtle.importKey(
        'jwk',
        JSON.parse(billData.publicKey),
        {
          name: 'ECDSA',
          namedCurve: 'P-256',
        },
        false,
        ['verify']
      );

      // Create data to verify
      const dataToVerify = JSON.stringify({
        serialNumber: billData.serialNumber,
        denomination: billData.denomination,
        timestamp: billData.timestamp,
      });

      const encoder = new TextEncoder();
      const dataBuffer = encoder.encode(dataToVerify);
      const signatureBuffer = Buffer.from(billData.signature, 'base64');

      // Verify
      const isValid = await subtle.verify(
        {
          name: 'ECDSA',
          hash: { name: 'SHA-256' },
        },
        publicKey,
        signatureBuffer,
        dataBuffer
      );

      return isValid;
    } catch (error) {
      console.error('Signature verification error:', error);
      return false;
    }
  }

  async verifyBill(billData) {
    const signatureValid = await this.verifySignature(billData);
    
    if (!signatureValid) {
      return {
        valid: false,
        reason: 'Invalid cryptographic signature - bill may be counterfeit',
      };
    }

    if (this.checkSpentList(billData.serialNumber)) {
      return {
        valid: false,
        reason: 'Bill already spent - duplicate detected',
      };
    }

    return {
      valid: true,
      reason: 'Bill is authentic and has not been spent',
    };
  }

  async acceptBill(billData) {
    const verification = await this.verifyBill(billData);
    
    if (verification.valid) {
      this.markAsSpent(billData.serialNumber);
      return true;
    }
    
    return false;
  }
}

module.exports = BillVerifier;
