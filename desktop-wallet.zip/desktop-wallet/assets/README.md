
# Icon Assets

Place your application icons here:

- `icon.png` - 512x512 PNG for Linux
- `icon.ico` - Windows icon (256x256 or multiple sizes)
- `icon.icns` - macOS icon (512x512 or multiple sizes)

For now, the build will use default Electron icons if these are missing.
