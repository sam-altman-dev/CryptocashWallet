# Bytecash Electrum Wallet - User Flow Documentation

## 🚨 Implementation Status

This document describes both **implemented** and **planned** features. Each section is clearly marked:
- ✅ **IMPLEMENTED**: Feature is working in current version
- 🚧 **PLANNED**: Feature is designed but not yet implemented (shows placeholder/mock)

---

## Overview

The Bytecash Electrum desktop wallet is an **offline-first cryptocurrency wallet** that manages cryptographically signed digital bills. Each bill is a unique, verifiable digital asset with ECDSA cryptographic signatures that prevent counterfeiting and double-spending.

## Core Concepts

### What is a Bytecash Bill?

A Bytecash Bill is a digital cryptocurrency bill that contains:
- **Serial Number**: Unique identifier (e.g., `BC-X9K2L-7823-MNOP`)
- **Denomination**: Value in USD ($20, $50, $100, etc.)
- **ECDSA Signature**: Cryptographic proof of authenticity using P-256 elliptic curve
- **Public Key**: For signature verification
- **Timestamp**: When the bill was minted

### How the Wallet Works

The wallet operates in **offline mode** for maximum security:
1. **Verifies** cryptographic signatures using ECDSA P-256 ✅
2. **Prevents double-spending** using a local spent list ✅
3. **Displays** wallet UI with sample bills ✅
4. **No internet required** for verification operations ✅

**Current Limitations:**
- ⚠️ Bills are hardcoded samples in the UI (not persisted to disk)
- ⚠️ Only spent_list.json is persisted
- ⚠️ Most user actions show placeholders/alerts

---

## User Flow #1: Initial Wallet Launch ✅ IMPLEMENTED

### Step-by-Step Process

**1. Application Startup**
- User double-clicks the Bytecash Electrum application icon
- Electron window launches with 1400x900 pixel interface
- Matrix-style background animation starts (falling green characters)

**2. Wallet Initialization**
```javascript
// What actually happens:
- Creates ~/.bytecash directory if it doesn't exist ✅
- Initializes spent_list.json (prevents double-spending) ✅
- Loads hardcoded sample bills (3 bills: $20, $50, $100) ✅
```

**3. Main Interface Display**
- **Left Sidebar**: Navigation menu with sections:
  - 💰 Wallet (active by default)
  - 📊 Transactions
  - 📤 Send
  - 📥 Receive
  - 🔍 Verify
  - ⚙️ Settings

- **Top Header**: "Portfolio" with action buttons:
  - "📷 Scan Bill" (shows alert - not implemented)
  - "+ Import Bill" (shows alert - not implemented)

- **Balance Card**: Shows:
  - Total Balance: $170.00 (hardcoded sum of 3 sample bills)
  - Number of bills: "3 Bills" (hardcoded)
  - Last sync time: "Just now" (hardcoded)
  - Quick action buttons (show alerts - not implemented)

- **Bills Grid**: Displays 3 hardcoded sample bills as cards

**4. Status Indicator**
- Bottom of sidebar shows "Offline Secure" with pulsing green dot ✅
- Indicates wallet is operating in secure offline mode

### What the Wallet Actually Does
✅ Creates secure storage directory (~/.bytecash/)  
✅ Creates spent_list.json for double-spend prevention  
✅ Displays beautiful UI with Matrix animation  
✅ Shows 3 hardcoded sample bills  
✅ Calculates and displays total balance from samples  
⚠️ Does NOT load bills from disk (bills are hardcoded in HTML)

---

## User Flow #2: Importing a New Bill 🚧 PLANNED (Shows Alert)

### Current Implementation

**1. User Clicks "+ Import Bill"**
- Button click triggers `importBill()` function
- **Shows alert**: "File picker would open here to import encrypted bill"
- **Does NOT actually import any files**

### Backend Verification Code ✅ IMPLEMENTED

The cryptographic verification code **IS implemented** in `crypto.js`:

```javascript
// Step 1: Signature Verification (IMPLEMENTED)
async verifySignature(billData) {
  1. Import the public key (ECDSA P-256) ✅
  2. Recreate the signed data (serial + denomination + timestamp) ✅
  3. Decode the base64 signature ✅
  4. Verify using Web Crypto API ✅
  5. Return true/false ✅
}

// Step 2: Double-Spend Check (IMPLEMENTED)
checkSpentList(serialNumber) {
  - Reads ~/.bytecash/spent_list.json ✅
  - Checks if serial number is in list ✅
  - Returns true if already spent ✅
}

// Step 3: Accept Bill (IMPLEMENTED)
async acceptBill(billData) {
  - Verifies signature ✅
  - Checks spent list ✅
  - Marks as spent if valid ✅
  - Writes to spent_list.json ✅
}
```

### What's Implemented vs Planned

✅ **IMPLEMENTED:**
- ECDSA P-256 signature verification
- Spent list checking and updating
- IPC handlers in main.js: `verify-bill`, `accept-bill`, `get-spent-count`
- BillVerifier class with full crypto verification

🚧 **NOT YET IMPLEMENTED:**
- File picker integration with renderer process
- Bill storage/persistence (bills not saved to disk)
- UI updates after importing
- Balance recalculation from imported bills

### Planned Flow (When Fully Implemented)

1. User clicks "+ Import Bill"
2. Native file picker opens (filter: .enc files)
3. Bill file is read and parsed
4. `verifyBill()` is called via IPC
5. If valid: Bill added to storage, UI updated, serial added to spent list
6. If invalid: Error shown with reason

---

## User Flow #3: Viewing Bill Details ✅ IMPLEMENTED (Basic)

### Step-by-Step Process

**1. User Sees Bills Grid** ✅
- Main content area shows 3 hardcoded sample bills
- Each bill displays as a card with:
  - Denomination badge ($20, $50, $100) ✅
  - Color coding (green, blue, purple) ✅
  - Serial number in monospace font ✅
  - Signature preview (truncated) ✅
  - "✓ Verified" status badge ✅
  - Position number ✅
  - "Offline Secure" label ✅

**2. User Clicks Bill Card**
- Card has hover effect (elevates, glows) ✅
- Click triggers `viewBill(id)` function
- **Shows alert**: "Viewing bill X - Full details would open here" ⚠️
- **Does NOT open detail view**

### What Each Bill Card Shows ✅

**Visual Indicators:**
- **Color-coded denomination:**
  - $20 = Green (#10B981) ✅
  - $50 = Blue (#3B82F6) ✅
  - $100 = Purple (#8B5CF6) ✅

- **Status Badge:** "✓ Verified" in green ✅
- **Serial Number:** `BC-X9K2L-7823-MNOP` (monospace font) ✅
- **Signature Preview:** `MEUCIQDa7B...x9F` (truncated) ✅

### What the Wallet Does
✅ Displays hardcoded sample bills with beautiful styling  
✅ Color-codes by denomination  
✅ Shows verification status badges  
✅ Provides hover effects  
⚠️ Bill click shows alert (detail view not implemented)

---

## User Flow #4: Scanning QR Code Bill 🚧 PLANNED (Shows Alert)

### Current Implementation

**1. User Clicks "📷 Scan Bill"**
- Button click triggers `scanBill()` function
- **Shows alert**: "QR Scanner would open here for offline verification"
- **Does NOT activate camera**
- **Does NOT scan QR codes**

### What's Implemented

✅ UI button exists and is clickable  
✅ Placeholder function defined  
⚠️ No camera integration  
⚠️ No QR code decoding  
⚠️ No QR verification flow

---

## User Flow #5: Sending Payment 🚧 PLANNED (Shows Alert)

### Current Implementation

**1. User Clicks "Send Payment"**
- Button in balance card quick actions
- **No action occurs** (placeholder button)

**2. Menu: Wallet → Send Payment**
- Menu item exists in application menu ✅
- Keyboard shortcut: Cmd/Ctrl+S ✅
- Sends IPC message: `send-payment` ✅
- **Renderer does not handle this message** ⚠️

### What's Implemented

✅ Application menu item  
✅ Keyboard shortcut  
✅ IPC message sending  
⚠️ No send payment UI  
⚠️ No bill selection  
⚠️ No transfer functionality

---

## User Flow #6: Receiving Payment 🚧 PLANNED

### Current Implementation

**1. Menu: Wallet → Receive Payment**
- Menu item exists in application menu ✅
- Keyboard shortcut: Cmd/Ctrl+R ✅
- Sends IPC message: `receive-payment` ✅
- **Renderer does not handle this message** ⚠️

### What's Implemented

✅ Application menu item  
✅ Keyboard shortcut  
⚠️ No receive UI  
⚠️ No QR code generation  
⚠️ No address display

---

## User Flow #7: Wallet Export/Backup 🚧 PARTIALLY IMPLEMENTED

### Current Implementation

**1. User Clicks "Export Wallet" or Menu Item**
- Button in balance card quick actions
- Or Menu: File → Export Wallet (Cmd/Ctrl+E) ✅
- IPC handler `export-wallet` exists in main.js ✅

**2. What Actually Happens**

```javascript
// main.js - IPC Handler (IMPLEMENTED)
ipcMain.handle('export-wallet', async () => {
  const result = await dialog.showSaveDialog(mainWindow, {
    defaultPath: 'bytecash-wallet-backup.json',
    filters: [
      { name: 'JSON Files', extensions: ['json'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });
  
  if (!result.canceled) {
    return result.filePath; // Returns file path
  }
  return null;
});
```

### What's Implemented vs Missing

✅ **IMPLEMENTED:**
- Application menu item with keyboard shortcut
- IPC handler in main.js
- Save dialog with proper filters and default filename

⚠️ **NOT IMPLEMENTED:**
- No renderer-side handler to call this IPC
- No actual export of wallet data
- No bill serialization
- No encryption of backup

---

## User Flow #8: Wallet Import/Restore 🚧 PLANNED

### Current Implementation

**1. Menu: File → Import Bill**
- Menu item exists ✅
- Keyboard shortcut: Cmd/Ctrl+I ✅
- IPC handler `import-bill-file` exists in main.js ✅

**2. What Actually Happens**

```javascript
// main.js - IPC Handler (IMPLEMENTED)
ipcMain.handle('import-bill-file', async () => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [
      { name: 'Bytecash Bills', extensions: ['enc'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });
  
  if (!result.canceled && result.filePaths.length > 0) {
    return result.filePaths[0]; // Returns selected file path
  }
  return null;
});
```

### What's Implemented vs Missing

✅ **IMPLEMENTED:**
- Application menu item with keyboard shortcut
- IPC handler returns selected file path
- File dialog with .enc filter

⚠️ **NOT IMPLEMENTED:**
- No renderer-side handler to use the file path
- No file reading/parsing
- No wallet restoration logic
- No bill import logic

---

## Security Features ✅ IMPLEMENTED

### Double-Spending Prevention ✅

**How It Works:**
1. Each bill has unique serial number ✅
2. `spent_list.json` stores all spent serial numbers ✅
3. `checkSpentList()` verifies serial not in list ✅
4. `markAsSpent()` adds serial to list ✅
5. File persists across app restarts ✅

**File Location:**
```
~/.bytecash/spent_list.json
```

**Example Spent List:**
```json
[
  "BC-X9K2L-7823-MNOP",
  "BC-M5TY8-4321-QRST"
]
```

**Implementation Status:**
- ✅ File creation and directory setup
- ✅ Read/write operations
- ✅ Check if serial is spent
- ✅ Add serial to spent list
- ✅ Prevents accepting spent bills
- ✅ Persistent across restarts

### Cryptographic Verification ✅ IMPLEMENTED

**ECDSA P-256 Signature Verification:**

```javascript
// FULLY IMPLEMENTED in crypto.js
async verifySignature(billData) {
  1. Import public key from bill (JWK format) ✅
  2. Reconstruct signed data (serial + denomination + timestamp) ✅
  3. Decode base64 signature ✅
  4. Use Web Crypto API to verify ✅
     - Algorithm: ECDSA
     - Curve: P-256  
     - Hash: SHA-256
  5. Returns true/false ✅
}
```

**Implementation Status:**
- ✅ ECDSA P-256 verification working
- ✅ Public key import from JWK
- ✅ Signature validation
- ✅ Web Crypto API integration
- ✅ IPC handlers for verification
- ⚠️ Not connected to UI import flow

### Offline Operation ✅

**What Works Offline:**
- ✅ Bill verification (cryptographic)
- ✅ Signature validation
- ✅ Double-spend checking
- ✅ Spent list operations
- ✅ UI display

**What Doesn't Work (Not Implemented):**
- ⚠️ Bill import from files
- ⚠️ Wallet backup
- ⚠️ Bill export
- ⚠️ QR code scanning

---

## Technical Details

### Bill Verification Flow ✅ IMPLEMENTED

```
IPC: verify-bill
      ↓
crypto.js: verifyBill(billData)
      ↓
Verify Signature:
  1. Import public key (ECDSA P-256) ✅
  2. Create data buffer: {serial, denomination, timestamp} ✅
  3. Decode signature from base64 ✅
  4. Verify using WebCrypto: subtle.verify() ✅
      ↓
  Valid? → Check Spent List ✅
      ↓
  Not Spent? → Return {valid: true, reason: "..."} ✅
      ↓
  Already Spent? → Return {valid: false, reason: "..."} ✅
```

**Implementation Status:**
- ✅ All verification logic implemented
- ✅ IPC handlers defined
- ⚠️ Not connected to file import UI

### Data Storage

**What's Actually Persisted:**
```
~/.bytecash/
  └── spent_list.json    ✅ (prevents double-spending)
```

**What's NOT Persisted (Hardcoded in HTML):**
- ⚠️ Bills (hardcoded in index.html)
- ⚠️ Wallet configuration
- ⚠️ Transaction history

---

## Summary: Implementation Status

### ✅ Fully Implemented

1. **Wallet UI** - Beautiful Matrix-themed interface
2. **Cryptographic Verification** - ECDSA P-256 signature verification
3. **Double-Spend Prevention** - Spent list with file persistence
4. **Application Menu** - All menu items and keyboard shortcuts
5. **IPC Handlers** - Backend handlers for verify, accept, import, export
6. **Bill Display** - Shows hardcoded sample bills with styling

### 🚧 Partially Implemented (Backend Only)

1. **Bill Import** - IPC handler exists, renderer integration missing
2. **Wallet Export** - IPC handler exists, actual export logic missing
3. **Bill Verification** - Backend works, not connected to import flow

### ⚠️ Not Implemented (Placeholders Only)

1. **QR Code Scanning** - Shows alert
2. **Send Payment** - IPC message sent, no UI
3. **Receive Payment** - IPC message sent, no UI
4. **Bill Storage** - Bills hardcoded, not persisted
5. **Wallet Restore** - No implementation
6. **Transaction History** - No implementation
7. **Settings** - No implementation

---

## Key Takeaways

**What Works:**
- 🔐 ECDSA P-256 cryptographic verification (fully functional)
- 🔐 Double-spending prevention (fully functional)
- 🔐 Offline operation (no network required)
- 🎨 Beautiful UI with Matrix theme
- 🎨 Sample bill display

**What Doesn't Work Yet:**
- ⚠️ Bill import from files (shows alert)
- ⚠️ Bill persistence (hardcoded samples only)
- ⚠️ Wallet backup/restore
- ⚠️ QR code features
- ⚠️ Send/receive functionality

**Next Steps for Full Implementation:**
1. Connect file import IPC handlers to renderer
2. Implement bill persistence to disk
3. Add wallet export logic
4. Implement QR code scanning
5. Build send/receive flows
6. Add transaction history

---

**Version:** 1.0.0  
**Implementation Status:** MVP - Core verification working, UI flows partially complete  
**Last Updated:** October 2025  
**Cryptography:** ECDSA P-256, SHA-256 (✅ Implemented)
