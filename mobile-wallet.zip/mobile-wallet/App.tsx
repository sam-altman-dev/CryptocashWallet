import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  SafeAreaView,
  StatusBar,
  Alert,
} from 'react-native';
import { verifyBill, acceptBill } from './crypto';

interface Bill {
  id: string;
  serialNumber: string;
  denomination: number;
  signature: string;
  color: string;
}

export default function App() {
  const [bills, setBills] = useState<Bill[]>([
    {
      id: '1',
      serialNumber: 'CC-L98KJH-9876-ABCD',
      denomination: 20,
      signature: 'MEU...A7B',
      color: '#10B981',
    },
    {
      id: '2',
      serialNumber: 'CC-M45TYU-5432-EFGH',
      denomination: 50,
      signature: 'MEU...C9D',
      color: '#3B82F6',
    },
    {
      id: '3',
      serialNumber: 'CC-N12QWE-3210-IJKL',
      denomination: 100,
      signature: 'MEU...E1F',
      color: '#8B5CF6',
    },
  ]);

  const totalValue = bills.reduce((sum, bill) => sum + bill.denomination, 0);

  const handleScanBill = async () => {
    // In production, this would open QR scanner
    // For now, simulate with alert
    Alert.alert(
      'Scan Bill',
      'QR Scanner would open here. Bill verification uses offline cryptographic signatures.',
      [{ text: 'OK' }]
    );
  };

  const handleVerifyBill = async (billData: any) => {
    const result = await verifyBill(billData);
    
    if (result.valid) {
      Alert.alert(
        '✓ Authentic Bill',
        result.reason,
        [
          {
            text: 'Accept Payment',
            onPress: async () => {
              await acceptBill(billData);
              Alert.alert('Success', 'Bill accepted and marked as spent');
            },
          },
          { text: 'Cancel', style: 'cancel' },
        ]
      );
    } else {
      Alert.alert('⚠️ Invalid Bill', result.reason, [{ text: 'OK' }]);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0f0c29" />
      
      {/* Header */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Bytecash</Text>
        <Text style={styles.headerSubtitle}>Wallet</Text>
      </View>

      {/* Balance Card */}
      <View style={styles.balanceCard}>
        <Text style={styles.balanceLabel}>Total Balance</Text>
        <Text style={styles.balanceAmount}>${totalValue.toFixed(2)}</Text>
        <View style={styles.balanceActions}>
          <TouchableOpacity style={styles.actionButton}>
            <Text style={styles.actionButtonText}>Send</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionButton, styles.actionButtonSecondary]}>
            <Text style={styles.actionButtonText}>Receive</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={[styles.actionButton, styles.actionButtonSecondary]}
            onPress={handleScanBill}
          >
            <Text style={styles.actionButtonText}>Scan</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Bills List */}
      <ScrollView style={styles.billsList} showsVerticalScrollIndicator={false}>
        <Text style={styles.sectionTitle}>Your Bills</Text>
        {bills.map((bill, index) => (
          <TouchableOpacity key={bill.id} style={styles.billCard}>
            <View style={[styles.billIndicator, { backgroundColor: bill.color }]} />
            <View style={styles.billContent}>
              <View style={styles.billHeader}>
                <Text style={styles.billDenomination}>${bill.denomination}</Text>
                <View style={styles.billBadge}>
                  <Text style={styles.billBadgeText}>✓ Verified</Text>
                </View>
              </View>
              <Text style={styles.billSerial}>{bill.serialNumber}</Text>
              <Text style={styles.billSignature} numberOfLines={1}>
                Signature: {bill.signature}
              </Text>
              <View style={styles.billFooter}>
                <Text style={styles.billFooterText}>Position: {index + 1}</Text>
                <Text style={styles.billFooterText}>Offline Secure</Text>
              </View>
            </View>
          </TouchableOpacity>
        ))}
        
        <TouchableOpacity style={styles.addBillButton}>
          <Text style={styles.addBillText}>+ Import New Bill</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Bottom Navigation */}
      <View style={styles.bottomNav}>
        <TouchableOpacity style={styles.navItem}>
          <Text style={[styles.navIcon, styles.navIconActive]}>💰</Text>
          <Text style={[styles.navLabel, styles.navLabelActive]}>Wallet</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem}>
          <Text style={styles.navIcon}>📊</Text>
          <Text style={styles.navLabel}>Activity</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.navItem}>
          <Text style={styles.navIcon}>⚙️</Text>
          <Text style={styles.navLabel}>Settings</Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0f0c29',
  },
  
  /* Coinbase-inspired professional styling with Matrix theme */
  header: {
    padding: 20,
    paddingTop: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(0, 255, 0, 0.1)',
  },
  headerTitle: {
    fontSize: 28,
    fontWeight: '700',
    color: '#00ff00',
    textShadowColor: 'rgba(0, 255, 0, 0.5)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 10,
    letterSpacing: 1,
  },
  headerSubtitle: {
    fontSize: 11,
    color: '#888',
    marginTop: 4,
    textTransform: 'uppercase',
    letterSpacing: 2,
  },
  balanceCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    margin: 20,
    marginTop: 10,
    padding: 24,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(0, 255, 0, 0.2)',
  },
  balanceLabel: {
    fontSize: 14,
    color: '#888',
    marginBottom: 8,
  },
  balanceAmount: {
    fontSize: 42,
    fontWeight: 'bold',
    color: '#fff',
    marginBottom: 20,
  },
  balanceActions: {
    flexDirection: 'row',
    gap: 12,
  },
  actionButton: {
    flex: 1,
    backgroundColor: '#00ff00',
    paddingVertical: 12,
    borderRadius: 8,
    alignItems: 'center',
  },
  actionButtonSecondary: {
    backgroundColor: 'rgba(0, 255, 0, 0.2)',
  },
  actionButtonText: {
    color: '#fff',
    fontWeight: '600',
    fontSize: 14,
  },
  billsList: {
    flex: 1,
    paddingHorizontal: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 16,
  },
  billCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 12,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(0, 255, 0, 0.2)',
    overflow: 'hidden',
    flexDirection: 'row',
  },
  billIndicator: {
    width: 6,
  },
  billContent: {
    flex: 1,
    padding: 16,
  },
  billHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  billDenomination: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#00ff00',
  },
  billBadge: {
    backgroundColor: 'rgba(0, 255, 0, 0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  billBadgeText: {
    color: '#00ff00',
    fontSize: 12,
    fontWeight: '600',
  },
  billSerial: {
    fontSize: 14,
    color: '#fff',
    fontFamily: 'monospace',
    marginBottom: 4,
  },
  billSignature: {
    fontSize: 12,
    color: '#888',
    fontFamily: 'monospace',
    marginBottom: 12,
  },
  billFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  billFooterText: {
    fontSize: 12,
    color: '#666',
  },
  addBillButton: {
    borderWidth: 2,
    borderColor: 'rgba(0, 255, 0, 0.3)',
    borderStyle: 'dashed',
    borderRadius: 12,
    padding: 24,
    alignItems: 'center',
    marginBottom: 20,
  },
  addBillText: {
    color: '#00ff00',
    fontSize: 16,
    fontWeight: '600',
  },
  bottomNav: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(0, 255, 0, 0.2)',
    paddingVertical: 8,
  },
  navItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 8,
  },
  navIcon: {
    fontSize: 24,
    marginBottom: 4,
    opacity: 0.5,
  },
  navIconActive: {
    opacity: 1,
  },
  navLabel: {
    fontSize: 12,
    color: '#888',
  },
  navLabelActive: {
    color: '#00ff00',
    fontWeight: '600',
  },
});
