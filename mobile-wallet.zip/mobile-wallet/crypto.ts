
import { Buffer } from 'buffer';

export interface BillData {
  serialNumber: string;
  denomination: number;
  timestamp: string;
  signature: string;
  publicKey: string;
  fingerprint: string;
}

// Verify ECDSA signature offline
export async function verifyBillSignature(
  billData: BillData
): Promise<boolean> {
  try {
    const crypto = window.crypto || (window as any).msCrypto;
    const subtle = crypto.subtle;

    // Import public key
    const publicKey = await subtle.importKey(
      'jwk',
      JSON.parse(billData.publicKey),
      {
        name: 'ECDSA',
        namedCurve: 'P-256',
      },
      false,
      ['verify']
    );

    // Create data hash to verify
    const dataToVerify = JSON.stringify({
      serialNumber: billData.serialNumber,
      denomination: billData.denomination,
      timestamp: billData.timestamp,
    });

    const encoder = new TextEncoder();
    const dataBuffer = encoder.encode(dataToVerify);
    const signatureBuffer = Buffer.from(billData.signature, 'base64');

    // Verify signature
    const isValid = await subtle.verify(
      {
        name: 'ECDSA',
        hash: { name: 'SHA-256' },
      },
      publicKey,
      signatureBuffer,
      dataBuffer
    );

    return isValid;
  } catch (error) {
    console.error('Signature verification error:', error);
    return false;
  }
}

// Check if bill was already spent locally
export function checkSpentList(serialNumber: string): boolean {
  const spentList = getSpentList();
  return spentList.includes(serialNumber);
}

// Add bill to spent list
export function markAsSpent(serialNumber: string): void {
  const spentList = getSpentList();
  if (!spentList.includes(serialNumber)) {
    spentList.push(serialNumber);
    localStorage.setItem('bytecash_spent_list', JSON.stringify(spentList));
  }
}

// Get spent list from local storage
function getSpentList(): string[] {
  const stored = localStorage.getItem('bytecash_spent_list');
  return stored ? JSON.parse(stored) : [];
}

// Verify bill completely (signature + double-spend check)
export async function verifyBill(billData: BillData): Promise<{
  valid: boolean;
  reason: string;
}> {
  // Check signature first
  const signatureValid = await verifyBillSignature(billData);
  
  if (!signatureValid) {
    return {
      valid: false,
      reason: 'Invalid cryptographic signature - bill may be counterfeit',
    };
  }

  // Check if already spent
  if (checkSpentList(billData.serialNumber)) {
    return {
      valid: false,
      reason: 'Bill already spent - duplicate detected',
    };
  }

  return {
    valid: true,
    reason: 'Bill is authentic and has not been spent',
  };
}

// Accept bill and mark as spent
export async function acceptBill(billData: BillData): Promise<boolean> {
  const verification = await verifyBill(billData);
  
  if (verification.valid) {
    markAsSpent(billData.serialNumber);
    return true;
  }
  
  return false;
}
